package com.example.demo.booking;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.user.User;



public interface BookingRepository extends JpaRepository<Booking, Integer> {

    List<Booking> findByCustomer(User customer);
}
