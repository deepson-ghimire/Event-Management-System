package com.example.demo.auth;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Utilities;
import com.example.demo.user.User;
import com.example.demo.user.UserRepository;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;

@Service
public class Authentication {
	
	@Autowired
	private UserRepository userRepository;

	public User authenticate(HttpServletRequest request) {
		
		//DONE: get the value of cookie SESSIONID
		Cookie[] cookies = request.getCookies();
		if(cookies == null) {
			return null;
		}
		
		Cookie userCookie = null;
		for(Cookie cookie: cookies) {
			if(cookie.getName().equals(Utilities.COOKIE_NAME)) {
				userCookie = cookie;
				System.out.println("Cookie found");
				break;
			}
		}
		
		//cookie SESSIONID not found
		if(userCookie == null) {
			return null;
		}
		
		//DONE: get user from database with given session ID
		User user = userRepository.findBySession(userCookie.getValue());
		
		//DONE: if user found: return that user
		//		if not found: redirect to /login
		
		 // If user exists, return it
	    if (user != null) {
	        return user;
	    }

	    // User not found in DB
	    return null; // controller can handle redirect to /login
	}
	 public User getLoggedInUser(HttpServletRequest request) {
	        return authenticate(request);
	    }

	
}