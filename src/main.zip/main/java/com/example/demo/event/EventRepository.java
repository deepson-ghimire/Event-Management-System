package com.example.demo.event;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;



public interface EventRepository extends JpaRepository<Event, Integer> {

    List<Event> findByApprovedTrue();

    List<Event> findByApprovedFalse();

}
