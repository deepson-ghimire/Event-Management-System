package com.example.demo.event;

import java.time.LocalDateTime;

import com.example.demo.category.Category;
import com.example.demo.user.User;
import com.example.demo.venue.Venue;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
@Entity
@Table(name = "event_tbl")
public class Event {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String description;

    private LocalDateTime eventStartDateTime;
    private LocalDateTime eventEndDateTime;

    private int guestCapacity;
    private Double ticketPrice;

    private LocalDateTime regStartDateTime;
    private LocalDateTime regEndDateTime;

    private String status;
    
    @Column(nullable = false)
	private boolean approved = false;

    @ManyToOne
    @JoinColumn(name = "category_id")
    private Category category;

    @ManyToOne
    @JoinColumn(name = "host_id")
    private User host;

    @ManyToOne
    @JoinColumn(name = "venue_id")
    private Venue venue;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public LocalDateTime getEventStartDateTime() {
		return eventStartDateTime;
	}

	public void setEventStartDateTime(LocalDateTime eventStartDateTime) {
		this.eventStartDateTime = eventStartDateTime;
	}

	public LocalDateTime getEventEndDateTime() {
		return eventEndDateTime;
	}

	public void setEventEndDateTime(LocalDateTime eventEndDateTime) {
		this.eventEndDateTime = eventEndDateTime;
	}

	public int getGuestCapacity() {
		return guestCapacity;
	}

	public void setGuestCapacity(int guestCapacity) {
		this.guestCapacity = guestCapacity;
	}

	public Double getTicketPrice() {
		return ticketPrice;
	}

	public void setTicketPrice(Double ticketPrice) {
		this.ticketPrice = ticketPrice;
	}

	public LocalDateTime getRegStartDateTime() {
		return regStartDateTime;
	}

	public void setRegStartDateTime(LocalDateTime regStartDateTime) {
		this.regStartDateTime = regStartDateTime;
	}

	public LocalDateTime getRegEndDateTime() {
		return regEndDateTime;
	}

	public void setRegEndDateTime(LocalDateTime regEndDateTime) {
		this.regEndDateTime = regEndDateTime;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public User getHost() {
		return host;
	}

	public void setHost(User host) {
		this.host = host;
	}

	public Venue getVenue() {
		return venue;
	}

	public void setVenue(Venue venue) {
		this.venue = venue;
	}


	public boolean isApproved() {
	    return approved;
	}

	public void setApproved(boolean approved) {
	    this.approved = approved;
	}

    
    
}

