package com.example.demo.event;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
@RequestMapping("/events")
public class EventController {

    @Autowired
    private EventRepository eventRepository;

    // ================= ADMIN =================

    // View all events (admin)
    @GetMapping("/admin")
    public String viewAllEvents(Model model) {
        List<Event> events = eventRepository.findAll();
        model.addAttribute("events", events);
        return "admin/events";
    }

    // Approve event (admin)
    @GetMapping("/approve/{id}")
    public String approveEvent(@PathVariable Integer id) {
        Event event = eventRepository.findById(id).orElse(null);
        if (event != null) {
            event.setApproved(true);
            eventRepository.save(event);
        }
        return "redirect:/events/admin";
    }

    // Reject event (admin)
    @GetMapping("/reject/{id}")
    public String rejectEvent(@PathVariable Integer id) {
        eventRepository.deleteById(id);
        return "redirect:/events/admin";
    }

    // ================= CUSTOMER =================

    // View approved events (customer)
    @GetMapping("/customer")
    public String viewApprovedEvents(Model model) {
        model.addAttribute("events", eventRepository.findByApprovedTrue());
        return "customer/events";
    }
}
