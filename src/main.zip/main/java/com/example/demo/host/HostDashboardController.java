package com.example.demo.host;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.auth.Authentication;
import com.example.demo.event.Event;
import com.example.demo.user.User;
import com.example.demo.user.UserType;

import jakarta.servlet.http.HttpServletRequest;

@Controller
@RequestMapping("/host")
public class HostDashboardController {


    @Autowired
    private Authentication authentication;

    // ================= DASHBOARD =================
    @GetMapping("/dashboard")
    public String getDashboard(HttpServletRequest request, Model model) {
		//DONE: get user from cookie
		// user verification
		// user identification
		User user = authentication.authenticate(request);
		
		if(user == null || user.getType() !=UserType.HOST) {
			return "redirect:/login";
		}
		
		model.addAttribute("user", user);
		return "host/dashboard.html";
	}

    // ================= ADD EVENT =================
    @GetMapping("/add-event")
    public String addEventForm(Model model) {
        model.addAttribute("event", new Event());
        return "host/add-event";
    }

//    @PostMapping("/save-event")
//    public String saveEvent(@ModelAttribute Event event) {
//
//        User host = authentication.getLoggedInUser();
//        event.setHost(host);
//        event.setApproved(false); // admin approval required
//
//        eventRepository.save(event);
//        return "redirect:/host/dashboard";
//    }
}
